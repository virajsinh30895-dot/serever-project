<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireRole('teacher');

// Get teacher details
$stmt = $pdo->prepare("SELECT * FROM teachers WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$teacher = $stmt->fetch();

// If teacher profile not found for some reason
if (!$teacher) {
    die("Teacher profile not found.");
}

$stmt_ass_cnt = $pdo->prepare("SELECT COUNT(*) FROM assignments WHERE teacher_id = ?");
$stmt_ass_cnt->execute([$teacher['id']]);
$ass_count = $stmt_ass_cnt->fetchColumn();

$stats = [
    'assignments' => $ass_count,
    'notices' => $pdo->query("SELECT COUNT(*) FROM notices WHERE target_role IN ('all', 'teacher')")->fetchColumn(),
    'courses' => $pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn(),
    'students' => $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn(),
];

// Recent notices
$notices = $pdo->query("SELECT title, created_at, target_role FROM notices WHERE target_role IN ('all', 'teacher') ORDER BY id DESC LIMIT 5")->fetchAll();

// Recent assignments by this teacher
$recent_assignments = $pdo->prepare("SELECT a.title, a.due_date, c.name as course_name FROM assignments a JOIN courses c ON a.course_id = c.id WHERE a.teacher_id = ? ORDER BY a.id DESC LIMIT 5");
$recent_assignments->execute([$teacher['id']]);
$assignments = $recent_assignments->fetchAll();

require_once '../includes/header.php';

$sidebar_role = 'teacher';
$current_page = 'index.php';
require_once '../includes/sidebar.php';
?>

<div class="dashboard-layout">
    <div class="dashboard-main">
        <?php
        $page_title = 'Teacher Dashboard';
        require_once '../includes/topbar.php';
        ?>

        <div class="dashboard-content">
            <!-- Page Header -->
            <div class="page-header animate-fade-in-up">
                <h1>Welcome, Prof. <?php echo htmlspecialchars($teacher['last_name']); ?>! 👋</h1>
                <p>Here's your teaching overview for today.</p>
            </div>

            <!-- Stat Cards -->
            <div class="stat-cards">
                <div class="stat-card blue animate-fade-in-up animate-delay-1">
                    <div class="stat-card-top">
                        <span class="stat-card-label">My Assignments</span>
                        <div class="stat-card-icon blue"><i class="bi bi-file-earmark-text-fill"></i></div>
                    </div>
                    <div class="stat-card-value"><?php echo $stats['assignments']; ?></div>
                    <span class="stat-card-trend up"><i class="bi bi-arrow-up-short"></i> Posted</span>
                </div>

                <div class="stat-card green animate-fade-in-up animate-delay-2">
                    <div class="stat-card-top">
                        <span class="stat-card-label">Available Courses</span>
                        <div class="stat-card-icon green"><i class="bi bi-journal-bookmark-fill"></i></div>
                    </div>
                    <div class="stat-card-value"><?php echo $stats['courses']; ?></div>
                    <span class="stat-card-trend neutral"><i class="bi bi-dash"></i> Active</span>
                </div>

                <div class="stat-card purple animate-fade-in-up animate-delay-3">
                    <div class="stat-card-top">
                        <span class="stat-card-label">Total Students</span>
                        <div class="stat-card-icon purple"><i class="bi bi-people-fill"></i></div>
                    </div>
                    <div class="stat-card-value"><?php echo $stats['students']; ?></div>
                    <span class="stat-card-trend up"><i class="bi bi-arrow-up-short"></i> Enrolled</span>
                </div>

                <div class="stat-card cyan animate-fade-in-up animate-delay-4">
                    <div class="stat-card-top">
                        <span class="stat-card-label">Active Notices</span>
                        <div class="stat-card-icon cyan"><i class="bi bi-megaphone-fill"></i></div>
                    </div>
                    <div class="stat-card-value"><?php echo $stats['notices']; ?></div>
                    <span class="stat-card-trend up"><i class="bi bi-arrow-up-short"></i> Recent</span>
                </div>
            </div>

            <!-- Main Content Row -->
            <div class="chart-grid animate-fade-in-up animate-delay-5">
                <!-- Recent Assignments -->
                <div class="content-card">
                    <div class="content-card-header">
                        <h3>My Recent Assignments</h3>
                        <a href="assignments.php" class="btn btn-sm btn-light">View All</a>
                    </div>
                    <div class="content-card-body">
                        <?php if (count($assignments) > 0): ?>
                        <ul class="data-list">
                            <?php foreach ($assignments as $a): 
                                $is_past = strtotime($a['due_date']) < time();
                            ?>
                                <li class="data-list-item">
                                    <div class="info">
                                        <div class="data-list-avatar" style="background: <?php echo $is_past ? 'var(--danger)' : 'var(--primary)'; ?>;">
                                            <i class="bi bi-file-earmark-text" style="font-size: 14px;"></i>
                                        </div>
                                        <div>
                                            <div class="name"><?php echo htmlspecialchars($a['title']); ?></div>
                                            <div class="subtitle"><?php echo htmlspecialchars($a['course_name']); ?></div>
                                        </div>
                                    </div>
                                    <span class="badge-tag" style="<?php echo $is_past ? 'color: var(--danger);' : ''; ?>">
                                        Due: <?php echo date('M d', strtotime($a['due_date'])); ?>
                                    </span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php else: ?>
                            <p style="color: var(--text-muted); text-align: center; padding: 20px 0;">No assignments posted yet.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="content-card">
                    <div class="content-card-header">
                        <h3>Quick Actions</h3>
                    </div>
                    <div class="content-card-body">
                        <div style="display: flex; flex-direction: column; gap: 10px;">
                            <a href="marks.php" class="quick-action-btn">
                                <i class="bi bi-clipboard-data-fill" style="color: var(--primary);"></i>
                                Upload Marks
                            </a>
                            <a href="assignments.php" class="quick-action-btn">
                                <i class="bi bi-file-earmark-plus-fill" style="color: var(--warning);"></i>
                                Post Assignment
                            </a>
                        </div>

                        <!-- Workload Donut Chart -->
                        <div style="margin-top: 24px;">
                            <h3 style="font-size: 14px; font-weight: 700; color: var(--text-primary); margin-bottom: 12px;">Workload Overview</h3>
                            <div style="height: 180px;">
                                <canvas id="workloadChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Notices Row -->
            <div class="content-card animate-fade-in-up">
                <div class="content-card-header">
                    <h3>Recent Notices</h3>
                </div>
                <div class="content-card-body">
                    <?php if (count($notices) > 0): ?>
                    <ul class="data-list">
                        <?php foreach ($notices as $notice): ?>
                            <li class="data-list-item">
                                <div class="info">
                                    <div class="data-list-avatar" style="background: var(--info);"><i class="bi bi-megaphone-fill" style="font-size: 14px;"></i></div>
                                    <div>
                                        <div class="name"><?php echo htmlspecialchars($notice['title']); ?></div>
                                        <div class="subtitle">For: <?php echo htmlspecialchars(ucfirst($notice['target_role'])); ?> · <?php echo date('M d, Y', strtotime($notice['created_at'])); ?></div>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php else: ?>
                        <p style="color: var(--text-muted); text-align: center; padding: 20px 0;">No notices at the moment.</p>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
// ===== Workload Donut =====
new Chart(document.getElementById('workloadChart'), {
    type: 'doughnut',
    data: {
        labels: ['Assignments', 'Courses', 'Notices'],
        datasets: [{
            data: [<?php echo $stats['assignments']; ?>, <?php echo $stats['courses']; ?>, <?php echo $stats['notices']; ?>],
            backgroundColor: ['#2563eb', '#10b981', '#06b6d4'],
            borderWidth: 0,
            hoverOffset: 6,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '60%',
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    padding: 12,
                    usePointStyle: true,
                    pointStyle: 'circle',
                    font: { family: 'Inter', size: 11, weight: '500' },
                    color: '#64748b'
                }
            }
        }
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>

