<?php
/**
 * reset_admin.php
 * Simple helper script to create or reset the admin password to a known value (admin123).
 */
require_once __DIR__ . '/includes/db.php';

try {
    $newHash = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = 'admin'");
    $stmt->execute();
    if ($stmt->fetch()) {
        $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE username = 'admin'");
        $stmt->execute([$newHash]);
        echo "Admin password has been reset to 'admin123'.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES ('admin', ?, 'admin')");
        $stmt->execute([$newHash]);
        echo "Admin user created with username 'admin' and password 'admin123'.";
    }
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}
?>
