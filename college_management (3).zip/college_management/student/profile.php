<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireRole('student');

$success = '';
$error = '';

$stmt = $pdo->prepare("SELECT * FROM students WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $phone = trim($_POST['phone']);

    if (empty($first_name) || empty($last_name)) {
        $error = "First name and last name are required.";
    } else {
        try {
            $update = $pdo->prepare("UPDATE students SET first_name = ?, last_name = ?, phone = ? WHERE user_id = ?");
            $update->execute([$first_name, $last_name, $phone, $_SESSION['user_id']]);
            $success = "Profile updated successfully.";
            
            // Refresh data
            $stmt->execute([$_SESSION['user_id']]);
            $student = $stmt->fetch();
        } catch(PDOException $e) {
            $error = "Failed to update profile.";
        }
    }
}

require_once '../includes/header.php';

$sidebar_role = 'student';
$current_page = 'profile.php';
require_once '../includes/sidebar.php';
?>

<div class="dashboard-layout">
    <div class="dashboard-main">
        <?php
        $page_title = 'My Profile';
        require_once '../includes/topbar.php';
        ?>

        <div class="dashboard-content">
            <div class="page-header animate-fade-in-up">
                <h1>My Profile</h1>
                <p>Manage your personal profile and account settings.</p>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-8 col-lg-6">
                    <div class="content-card animate-fade-in-up">
                        <div class="content-card-body">
                            <form method="POST" action="profile.php" class="needs-validation" novalidate>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label fw-semibold">First Name *</label>
                                        <input type="text" class="form-control" name="first_name" value="<?php echo htmlspecialchars($student['first_name']); ?>" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-semibold">Last Name *</label>
                                        <input type="text" class="form-control" name="last_name" value="<?php echo htmlspecialchars($student['last_name']); ?>" required>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label fw-semibold">Email Address (Cannot change)</label>
                                        <input type="email" class="form-control bg-light" value="<?php echo htmlspecialchars($student['email']); ?>" readonly disabled>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label fw-semibold">Phone Number</label>
                                        <input type="text" class="form-control" name="phone" value="<?php echo htmlspecialchars($student['phone'] ?? ''); ?>">
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label fw-semibold">Enrollment Date</label>
                                        <input type="text" class="form-control bg-light" value="<?php echo htmlspecialchars($student['enrollment_date']); ?>" readonly disabled>
                                    </div>
                                </div>
                                <div class="mt-4 text-end">
                                    <button type="submit" class="btn btn-primary px-4 shadow-sm rounded-pill">Update Profile</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
