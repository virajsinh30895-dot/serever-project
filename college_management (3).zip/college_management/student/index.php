<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireRole('student');

// Get student details
$stmt = $pdo->prepare("SELECT s.*, c.name as course_name FROM students s LEFT JOIN courses c ON s.course_id = c.id WHERE s.user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch();

if (!$student) {
    die("Student profile not found.");
}

$student_id = $student['id'];

// Get assignments count
$assignments_count = 0;
if (!empty($student['course_id'])) {
    $stmt_ass = $pdo->prepare("SELECT COUNT(*) FROM assignments WHERE course_id = ?");
    $stmt_ass->execute([$student['course_id']]);
    $assignments_count = $stmt_ass->fetchColumn();
}

// Get notices count
$stmt_notices = $pdo->query("SELECT COUNT(*) FROM notices WHERE target_role IN ('all', 'student')");
$notices_count = $stmt_notices->fetchColumn();

// Get marks count and average
$stmt_marks_count = $pdo->prepare("SELECT COUNT(*) FROM marks WHERE student_id = ?");
$stmt_marks_count->execute([$student_id]);
$marks_count = $stmt_marks_count->fetchColumn();

$stmt_avg = $pdo->prepare("SELECT SUM(marks_obtained) as total_obt, SUM(total_marks) as total_max FROM marks WHERE student_id = ?");
$stmt_avg->execute([$student_id]);
$avg_data = $stmt_avg->fetch();
$avg_pct = ($avg_data && $avg_data['total_max'] > 0) ? round(($avg_data['total_obt'] / $avg_data['total_max']) * 100, 1) : 0;

$stats = [
    'marks_count' => $marks_count,
    'avg_pct' => $avg_pct,
    'assignments' => $assignments_count,
    'notices' => $notices_count
];

// Recent marks
$recent_marks_stmt = $pdo->prepare("SELECT c.name as course_name, m.exam_name, m.marks_obtained, m.total_marks FROM marks m JOIN courses c ON m.course_id = c.id WHERE m.student_id = ? ORDER BY m.id DESC LIMIT 5");
$recent_marks_stmt->execute([$student_id]);
$recent_marks = $recent_marks_stmt->fetchAll();

// Recent notices
$recent_notices = $pdo->query("SELECT title, created_at FROM notices WHERE target_role IN ('all', 'student') ORDER BY id DESC LIMIT 5")->fetchAll();

require_once '../includes/header.php';

$sidebar_role = 'student';
$current_page = 'index.php';
require_once '../includes/sidebar.php';
?>

<div class="dashboard-layout">
    <div class="dashboard-main">
        <?php
        $page_title = 'Student Dashboard';
        require_once '../includes/topbar.php';
        ?>

        <div class="dashboard-content">
            <!-- Page Header -->
            <div class="page-header animate-fade-in-up">
                <h1>Welcome, <?php echo htmlspecialchars($student['first_name']); ?>! ??</h1>
                <p>Here's your academic overview at a glance.</p>
            </div>

            <!-- Stat Cards -->
            <div class="stat-cards">
                <div class="stat-card blue animate-fade-in-up animate-delay-1">
                    <div class="stat-card-top">
                        <span class="stat-card-label">My Course</span>
                        <div class="stat-card-icon blue"><i class="bi bi-journal-bookmark-fill"></i></div>
                    </div>
                    <div class="stat-card-value" style="font-size: 20px;"><?php echo htmlspecialchars($student['course_name'] ?? 'Not Assigned'); ?></div>
                    <span class="stat-card-trend neutral"><i class="bi bi-mortarboard-fill"></i> Enrolled</span>
                </div>

                <div class="stat-card green animate-fade-in-up animate-delay-2">
                    <div class="stat-card-top">
                        <span class="stat-card-label">Average Score</span>
                        <div class="stat-card-icon green"><i class="bi bi-award-fill"></i></div>
                    </div>
                    <div class="stat-card-value"><?php echo $avg_pct; ?>%</div>
                    <span class="stat-card-trend <?php echo $avg_pct >= 50 ? 'up' : 'down'; ?>">
                        <i class="bi bi-arrow-<?php echo $avg_pct >= 50 ? 'up' : 'down'; ?>-short"></i>
                        <?php echo $marks_count; ?> Exam(s)
                    </span>
                </div>

                <div class="stat-card yellow animate-fade-in-up animate-delay-3">
                    <div class="stat-card-top">
                        <span class="stat-card-label">Assignments</span>
                        <div class="stat-card-icon yellow"><i class="bi bi-file-earmark-text-fill"></i></div>
                    </div>
                    <div class="stat-card-value"><?php echo $stats['assignments']; ?></div>
                    <span class="stat-card-trend neutral"><i class="bi bi-dash"></i> Total</span>
                </div>

                <div class="stat-card cyan animate-fade-in-up animate-delay-4">
                    <div class="stat-card-top">
                        <span class="stat-card-label">Notices</span>
                        <div class="stat-card-icon cyan"><i class="bi bi-megaphone-fill"></i></div>
                    </div>
                    <div class="stat-card-value"><?php echo $stats['notices']; ?></div>
                    <span class="stat-card-trend up"><i class="bi bi-arrow-up-short"></i> Active</span>
                </div>
            </div>

            <!-- Charts & Content Row -->
            <div class="chart-grid animate-fade-in-up animate-delay-5">
                <!-- Marks Chart -->
                <div class="content-card">
                    <div class="content-card-header">
                        <h3>Marks Overview</h3>
                        <a href="marks.php" class="btn btn-sm btn-light">View All</a>
                    </div>
                    <div class="content-card-body">
                        <div class="chart-container" style="height: 260px;">
                            <canvas id="marksChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Recent Notices -->
                <div class="content-card">
                    <div class="content-card-header">
                        <h3>Recent Notices</h3>
                        <a href="notices.php" class="btn btn-sm btn-light">View All</a>
                    </div>
                    <div class="content-card-body">
                        <?php if (count($recent_notices) > 0): ?>
                        <ul class="data-list">
                            <?php foreach ($recent_notices as $n): ?>
                                <li class="data-list-item">
                                    <div class="info">
                                        <div class="data-list-avatar" style="background: var(--info);"><i class="bi bi-megaphone-fill" style="font-size: 14px;"></i></div>
                                        <div>
                                            <div class="name" style="max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"><?php echo htmlspecialchars($n['title']); ?></div>
                                            <div class="subtitle"><?php echo date('M d, Y', strtotime($n['created_at'])); ?></div>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php else: ?>
                            <p style="color: var(--text-muted); text-align: center; padding: 20px 0;">No new notices.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Bottom Row: Recent Marks Table -->
            <div class="content-card animate-fade-in-up mt-4">
                <div class="content-card-header">
                    <h3>Recent Marks Evaluation</h3>
                    <a href="marks.php" class="btn btn-sm btn-light">View All Marks</a>
                </div>
                <div class="content-card-body">
                    <?php if (count($recent_marks) > 0): ?>
                    <ul class="data-list">
                        <?php foreach ($recent_marks as $m): 
                            $pct = $m['total_marks'] > 0 ? round(($m['marks_obtained'] / $m['total_marks']) * 100) : 0;
                            $pct_color = $pct >= 80 ? 'var(--success)' : ($pct >= 50 ? 'var(--warning)' : 'var(--danger)');
                        ?>
                            <li class="data-list-item">
                                <div class="info">
                                    <div class="data-list-avatar" style="background: <?php echo $pct_color; ?>;">
                                        <?php echo $pct; ?>%
                                    </div>
                                    <div>
                                        <div class="name"><?php echo htmlspecialchars($m['course_name']); ?></div>
                                        <div class="subtitle"><?php echo htmlspecialchars($m['exam_name']); ?></div>
                                    </div>
                                </div>
                                <span class="badge-tag"><?php echo floatval($m['marks_obtained']); ?> / <?php echo floatval($m['total_marks']); ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php else: ?>
                        <p style="color: var(--text-muted); text-align: center; padding: 20px 0;">No marks available yet.</p>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
// ===== Marks Bar Chart =====
const marksLabels = <?php echo json_encode(array_column($recent_marks, 'exam_name')); ?>;
const marksObtained = <?php echo json_encode(array_map('floatval', array_column($recent_marks, 'marks_obtained'))); ?>;
const marksTotal = <?php echo json_encode(array_map('floatval', array_column($recent_marks, 'total_marks'))); ?>;

new Chart(document.getElementById('marksChart'), {
    type: 'bar',
    data: {
        labels: marksLabels.length > 0 ? marksLabels : ['No Data'],
        datasets: [{
            label: 'Obtained',
            data: marksObtained.length > 0 ? marksObtained : [0],
            backgroundColor: '#2563eb',
            borderRadius: 6,
            barPercentage: 0.6,
        }, {
            label: 'Total',
            data: marksTotal.length > 0 ? marksTotal : [0],
            backgroundColor: '#e2e8f0',
            borderRadius: 6,
            barPercentage: 0.6,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    padding: 16,
                    usePointStyle: true,
                    pointStyle: 'circle',
                    font: { family: 'Inter', size: 12, weight: '500' },
                    color: '#64748b'
                }
            }
        },
        scales: {
            x: { grid: { display: false }, ticks: { font: { family: 'Inter', size: 11 }, color: '#94a3b8' } },
            y: { beginAtZero: true, grid: { color: 'rgba(226,232,240,0.6)', drawBorder: false }, ticks: { font: { family: 'Inter', size: 11 }, color: '#94a3b8' } }
        }
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>
