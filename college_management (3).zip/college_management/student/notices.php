<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireRole('student');

$notices = $pdo->query("
    SELECT n.*, u.username as poster_name 
    FROM notices n 
    JOIN users u ON n.posted_by = u.id 
    WHERE n.target_role IN ('all', 'student') 
    ORDER BY n.id DESC
")->fetchAll();

require_once '../includes/header.php';

$sidebar_role = 'student';
$current_page = 'notices.php';
require_once '../includes/sidebar.php';
?>

<div class="dashboard-layout">
    <div class="dashboard-main">
        <?php
        $page_title = 'College Notices';
        require_once '../includes/topbar.php';
        ?>

        <div class="dashboard-content">
            <div class="page-header animate-fade-in-up">
                <h1>College Notices</h1>
                <p>Important updates and announcements from the administration and faculty.</p>
            </div>

            <div class="row animate-fade-in-up">
                <div class="col-md-10 col-lg-8">
                    <?php if(count($notices) > 0): ?>
                        <div class="content-card p-0 overflow-hidden">
                            <div class="list-group list-group-flush">
                                <?php foreach($notices as $notice): ?>
                                    <div class="list-group-item p-4 bg-transparent border-bottom">
                                        <div class="d-flex w-100 justify-content-between align-items-start mb-2">
                                            <h5 class="mb-1 fw-bold text-primary"><?php echo htmlspecialchars($notice['title']); ?></h5>
                                            <small class="text-muted badge bg-secondary-subtle text-secondary border border-secondary-subtle px-3 py-1 rounded-pill">
                                                <?php echo date('M d, Y', strtotime($notice['created_at'])); ?>
                                            </small>
                                        </div>
                                        <p class="mb-3 text-secondary lh-base"><?php echo nl2br(htmlspecialchars($notice['content'])); ?></p>
                                        <div class="d-flex align-items-center">
                                            <small class="text-muted d-flex align-items-center">
                                                <i class="bi bi-person-circle me-2 fs-6 text-primary"></i>
                                                Posted by: <?php echo htmlspecialchars($notice['poster_name']); ?>
                                            </small>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="content-card text-center py-5">
                            <p class="text-muted mb-0">No notices available for you.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
