<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireRole('student');

$stmt = $pdo->prepare("SELECT course_id FROM students WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch();
$course_id = $student['course_id'];

$assignments = [];
if ($course_id) {
    $stmt = $pdo->prepare("
        SELECT a.*, t.first_name as teacher_fname, t.last_name as teacher_lname 
        FROM assignments a 
        JOIN teachers t ON a.teacher_id = t.id 
        WHERE a.course_id = ? 
        ORDER BY a.due_date DESC
    ");
    $stmt->execute([$course_id]);
    $assignments = $stmt->fetchAll();
}

require_once '../includes/header.php';

$sidebar_role = 'student';
$current_page = 'assignments.php';
require_once '../includes/sidebar.php';
?>

<div class="dashboard-layout">
    <div class="dashboard-main">
        <?php
        $page_title = 'Assignments';
        require_once '../includes/topbar.php';
        ?>

        <div class="dashboard-content">
            <div class="page-header animate-fade-in-up">
                <h1>Course Assignments</h1>
                <p>View coursework, project briefs, and downloadable resource materials.</p>
            </div>

            <?php if (!$course_id): ?>
                <div class="alert alert-warning animate-fade-in-up" role="alert">
                    <i class="bi bi-exclamation-triangle me-2"></i>You are not assigned to any course yet. Please contact an administrator.
                </div>
            <?php else: ?>
                <div class="row g-4 animate-fade-in-up">
                    <?php if(count($assignments) > 0): ?>
                        <?php foreach($assignments as $a): ?>
                            <div class="col-md-6 col-xl-4">
                                <div class="content-card h-100">
                                    <div class="content-card-body">
                                        <div class="d-flex justify-content-between align-items-start mb-2">
                                            <h5 class="fw-bold text-dark mb-0"><?php echo htmlspecialchars($a['title']); ?></h5>
                                        </div>
                                        <p class="text-muted small mb-3">Posted by Prof. <?php echo htmlspecialchars($a['teacher_lname']); ?></p>
                                        
                                        <p class="card-text text-secondary mb-3" style="min-height: 2.5rem;">
                                            <?php echo nl2br(htmlspecialchars($a['description'] ?? 'No description provided.')); ?>
                                        </p>
                                        
                                        <hr class="my-3 opacity-25">
                                        
                                        <div class="d-flex justify-content-between align-items-center">
                                            <?php 
                                            $due = strtotime($a['due_date']);
                                            $now = time();
                                            $badge_color = ($due < $now) ? 'danger' : 'success';
                                            ?>
                                            <span class="badge bg-<?php echo $badge_color; ?>-subtle text-<?php echo $badge_color; ?> border border-<?php echo $badge_color; ?>-subtle px-2 py-1">
                                                Due: <?php echo date('M d, Y', $due); ?>
                                            </span>
                                            
                                            <?php if($a['file_path']): ?>
                                                <a href="../<?php echo htmlspecialchars($a['file_path']); ?>" target="_blank" class="btn btn-sm btn-primary rounded-pill px-3 shadow-sm">
                                                    <i class="bi bi-download me-1"></i>Download
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="col-12">
                            <div class="content-card text-center py-5">
                                <p class="text-muted mb-0">No assignments posted for your course yet.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
