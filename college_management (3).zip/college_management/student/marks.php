<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireRole('student');

$stmt = $pdo->prepare("SELECT id FROM students WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch();
$student_id = $student['id'];

$marks = $pdo->prepare("
    SELECT c.name as course_name, c.code as course_code, m.exam_name, m.marks_obtained, m.total_marks 
    FROM marks m 
    JOIN courses c ON m.course_id = c.id 
    WHERE m.student_id = ? 
    ORDER BY c.name ASC, m.id DESC
");
$marks->execute([$student_id]);
$records = $marks->fetchAll();

require_once '../includes/header.php';

$sidebar_role = 'student';
$current_page = 'marks.php';
require_once '../includes/sidebar.php';
?>

<div class="dashboard-layout">
    <div class="dashboard-main">
        <?php
        $page_title = 'My Marks';
        require_once '../includes/topbar.php';
        ?>

        <div class="dashboard-content">
            <div class="page-header animate-fade-in-up">
                <h1>My Marks</h1>
                <p>View your exam grades and academic performance evaluation.</p>
            </div>

            <div class="content-card animate-fade-in-up">
                <div class="content-card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Course</th>
                                    <th>Exam / Test</th>
                                    <th>Marks Obtained</th>
                                    <th>Total Marks</th>
                                    <th>Percentage</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($records) > 0): ?>
                                    <?php foreach($records as $rec): ?>
                                        <tr>
                                            <td class="fw-semibold">
                                                <span class="badge bg-primary-subtle text-primary border border-primary-subtle me-2"><?php echo htmlspecialchars($rec['course_code']); ?></span>
                                                <?php echo htmlspecialchars($rec['course_name']); ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($rec['exam_name']); ?></td>
                                            <td class="fw-bold text-primary fs-6"><?php echo floatval($rec['marks_obtained']); ?></td>
                                            <td class="text-muted"><?php echo floatval($rec['total_marks']); ?></td>
                                            <td>
                                                <?php 
                                                $pct = $rec['total_marks'] > 0 ? round(($rec['marks_obtained'] / $rec['total_marks']) * 100, 1) : 0;
                                                $color = $pct >= 80 ? 'success' : ($pct >= 50 ? 'warning' : 'danger');
                                                ?>
                                                <span class="badge bg-<?php echo $color; ?>-subtle text-<?php echo $color; ?> border border-<?php echo $color; ?>-subtle px-3 py-1"><?php echo $pct; ?>%</span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="5" class="text-center text-muted py-4">No marks have been entered for you yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
