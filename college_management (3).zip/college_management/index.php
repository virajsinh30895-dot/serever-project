<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';

// If user is already logged in, redirect them to their dashboard
redirectBasedOnRole();

require_once 'includes/header.php';
?>

<div class="auth-wrapper" style="flex-direction: column; gap: 40px;">
    <!-- Hero Text -->
    <div class="landing-hero">
        <div class="landing-logo-container">
            <img src="assets/img/smart-college-logo.png" alt="Smart College Logo" class="landing-logo">
        </div>
        <h1>Smart College</h1>
        <p>A modern, professional portal for students and administrators to manage academic life effectively and efficiently.</p>
    </div>

    <!-- Feature Cards -->
    <div class="landing-features">
        <div class="landing-feature-card">
            <i class="bi bi-people-fill"></i>
            <h4>Students</h4>
            <p>Access grades, assignments, and course materials.</p>
        </div>

        <div class="landing-feature-card">
            <i class="bi bi-shield-lock-fill"></i>
            <h4>Admin</h4>
            <p>Manage users, courses, and overall system data.</p>
        </div>
    </div>

    <!-- CTA Buttons -->
    <div class="landing-buttons">
        <a href="login.php" class="btn-white">Login to Portal</a>
        <a href="register.php" class="btn-ghost">Register as Student</a>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>


