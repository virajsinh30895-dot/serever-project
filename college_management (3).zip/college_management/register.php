<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';

redirectBasedOnRole();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);

    if (empty($username) || empty($password) || empty($first_name) || empty($last_name) || empty($email)) {
        $error = 'Please fill in all required fields.';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } else {
        // Check if username or email exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $error = 'Username is already taken.';
        } else {
            $stmt = $pdo->prepare("SELECT id FROM students WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = 'Email is already registered.';
            } else {
                try {
                    $pdo->beginTransaction();

                    // Insert user
                    $password_hash = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'student')");
                    $stmt->execute([$username, $password_hash]);
                    $user_id = $pdo->lastInsertId();

                    // Insert student profile
                    $stmt = $pdo->prepare("INSERT INTO students (user_id, first_name, last_name, email, phone, enrollment_date) VALUES (?, ?, ?, ?, ?, CURDATE())");
                    $stmt->execute([$user_id, $first_name, $last_name, $email, $phone]);

                    $pdo->commit();
                    $success = 'Registration successful! You can now login.';
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $error = 'Registration failed. Please try again.';
                }
            }
        }
    }
}

require_once 'includes/header.php';
?>

<div class="auth-wrapper">
    <div class="auth-card wide">
        <div class="text-center mb-4">
            <div style="width: 56px; height: 56px; background: linear-gradient(135deg, var(--primary), var(--purple)); border-radius: 14px; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; color: #fff; font-size: 24px;">
                <i class="bi bi-person-plus-fill"></i>
            </div>
            <h2>Student Registration</h2>
            <p class="subtitle">Create your account to access the portal</p>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger" role="alert">
                <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success" role="alert">
                <i class="bi bi-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
            </div>
            <div class="text-center mt-3 mb-2">
                <a href="login.php" class="btn btn-primary" style="max-width: 200px;">Go to Login</a>
            </div>
        <?php else: ?>

        <form method="POST" action="register.php">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="first_name" class="form-label">First Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="first_name" name="first_name" placeholder="John" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="last_name" class="form-label">Last Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Doe" required>
                </div>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email Address <span class="text-danger">*</span></label>
                <input type="email" class="form-control" id="email" name="email" placeholder="john@example.com" required>
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label">Phone Number</label>
                <input type="text" class="form-control" id="phone" name="phone" placeholder="+91 98765 43210">
            </div>
            <hr style="border-color: var(--border-color); margin: 20px 0;">
            <div class="mb-3">
                <label for="username" class="form-label">Username <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="username" name="username" placeholder="Choose a username" required>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="password" class="form-label">Password <span class="text-danger">*</span></label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Min 6 characters" required minlength="6">
                </div>
                <div class="col-md-6 mb-4">
                    <label for="confirm_password" class="form-label">Confirm Password <span class="text-danger">*</span></label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Re-enter password" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Create Account</button>
        </form>
        
        <div class="auth-footer">
            Already have an account? <a href="login.php">Sign in here</a>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
