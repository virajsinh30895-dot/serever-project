<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireRole('admin');

// Fetch statistics
$stats = [
    'students' => $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn(),
    'teachers' => $pdo->query("SELECT COUNT(*) FROM teachers")->fetchColumn(),
    'courses'  => $pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn(),
    'notices'  => $pdo->query("SELECT COUNT(*) FROM notices")->fetchColumn(),
];

// Fetch recent students
$recent_students = $pdo->query("SELECT first_name, last_name, email, enrollment_date FROM students ORDER BY id DESC LIMIT 5")->fetchAll();

// Fetch recent notices
$recent_notices = $pdo->query("SELECT title, created_at, target_role FROM notices ORDER BY id DESC LIMIT 5")->fetchAll();

// Fetch monthly enrollment data for chart (last 6 months)
$enrollment_data = [];
for ($i = 5; $i >= 0; $i--) {
    $month = date('Y-m', strtotime("-$i months"));
    $count = $pdo->query("SELECT COUNT(*) FROM students WHERE DATE_FORMAT(enrollment_date, '%Y-%m') = '$month'")->fetchColumn();
    $enrollment_data[] = [
        'label' => date('M', strtotime("-$i months")),
        'count' => (int)$count
    ];
}

// Fetch course-wise student count for donut chart
$course_stats = $pdo->query("SELECT c.name, COUNT(s.id) as student_count FROM courses c LEFT JOIN students s ON s.course_id = c.id GROUP BY c.id, c.name ORDER BY student_count DESC LIMIT 5")->fetchAll();

require_once '../includes/header.php';

$sidebar_role = 'admin';
$current_page = 'index.php';
require_once '../includes/sidebar.php';
?>

<div class="dashboard-layout">
    <!-- Sidebar already rendered -->

    <div class="dashboard-main">
        <?php
        $page_title = 'Admin Dashboard';
        require_once '../includes/topbar.php';
        ?>

        <div class="dashboard-content">
            <!-- Page Header -->
            <div class="page-header animate-fade-in-up">
                <h1>Dashboard</h1>
                <p>Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>! Here's what's happening.</p>
            </div>

            <!-- Stat Cards -->
            <div class="stat-cards">
                <div class="stat-card blue animate-fade-in-up animate-delay-1">
                    <div class="stat-card-top">
                        <span class="stat-card-label">Total Students</span>
                        <div class="stat-card-icon blue"><i class="bi bi-people-fill"></i></div>
                    </div>
                    <div class="stat-card-value"><?php echo number_format($stats['students']); ?></div>
                    <span class="stat-card-trend up"><i class="bi bi-arrow-up-short"></i> Active</span>
                </div>

                <div class="stat-card green animate-fade-in-up animate-delay-2">
                    <div class="stat-card-top">
                        <span class="stat-card-label">Total Teachers</span>
                        <div class="stat-card-icon green"><i class="bi bi-person-badge-fill"></i></div>
                    </div>
                    <div class="stat-card-value"><?php echo number_format($stats['teachers']); ?></div>
                    <span class="stat-card-trend up"><i class="bi bi-arrow-up-short"></i> Active</span>
                </div>

                <div class="stat-card yellow animate-fade-in-up animate-delay-3">
                    <div class="stat-card-top">
                        <span class="stat-card-label">Total Courses</span>
                        <div class="stat-card-icon yellow"><i class="bi bi-journal-bookmark-fill"></i></div>
                    </div>
                    <div class="stat-card-value"><?php echo number_format($stats['courses']); ?></div>
                    <span class="stat-card-trend neutral"><i class="bi bi-dash"></i> Stable</span>
                </div>

                <div class="stat-card cyan animate-fade-in-up animate-delay-4">
                    <div class="stat-card-top">
                        <span class="stat-card-label">Notices</span>
                        <div class="stat-card-icon cyan"><i class="bi bi-megaphone-fill"></i></div>
                    </div>
                    <div class="stat-card-value"><?php echo number_format($stats['notices']); ?></div>
                    <span class="stat-card-trend up"><i class="bi bi-arrow-up-short"></i> Recent</span>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="chart-grid animate-fade-in-up animate-delay-5">
                <!-- Line Chart: Student Enrollment Trend -->
                <div class="content-card">
                    <div class="content-card-header">
                        <h3>Student Enrollment Trend</h3>
                        <div class="chart-toggle-btns">
                            <button class="chart-toggle-btn active">Monthly</button>
                            <button class="chart-toggle-btn">Yearly</button>
                        </div>
                    </div>
                    <div class="content-card-body">
                        <div class="chart-container">
                            <canvas id="enrollmentChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Donut Chart: Course Distribution -->
                <div class="content-card">
                    <div class="content-card-header">
                        <h3>Course Distribution</h3>
                    </div>
                    <div class="content-card-body">
                        <div class="chart-container">
                            <canvas id="courseChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Bottom Row: Recent Students & Notices -->
            <div class="chart-grid">
                <!-- Recent Students -->
                <div class="content-card animate-fade-in-up">
                    <div class="content-card-header">
                        <h3>Recent Students</h3>
                        <a href="students.php" class="btn btn-sm btn-light">View All</a>
                    </div>
                    <div class="content-card-body">
                        <?php if (count($recent_students) > 0): ?>
                        <ul class="data-list">
                            <?php 
                            $colors = ['#2563eb', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];
                            foreach ($recent_students as $i => $student): 
                                $color = $colors[$i % count($colors)];
                                $init = strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1));
                            ?>
                                <li class="data-list-item">
                                    <div class="info">
                                        <div class="data-list-avatar" style="background: <?php echo $color; ?>;"><?php echo $init; ?></div>
                                        <div>
                                            <div class="name"><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></div>
                                            <div class="subtitle"><?php echo htmlspecialchars($student['email']); ?></div>
                                        </div>
                                    </div>
                                    <span class="badge-tag"><?php echo htmlspecialchars($student['enrollment_date']); ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php else: ?>
                            <p style="color: var(--text-muted); text-align: center; padding: 20px 0;">No students registered yet.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Recent Notices -->
                <div class="content-card animate-fade-in-up">
                    <div class="content-card-header">
                        <h3>Recent Notices</h3>
                        <a href="notices.php" class="btn btn-sm btn-light">Manage</a>
                    </div>
                    <div class="content-card-body">
                        <?php if (count($recent_notices) > 0): ?>
                        <ul class="data-list">
                            <?php foreach ($recent_notices as $notice): ?>
                                <li class="data-list-item">
                                    <div class="info">
                                        <div class="data-list-avatar" style="background: var(--info);"><i class="bi bi-megaphone-fill" style="font-size: 14px;"></i></div>
                                        <div>
                                            <div class="name" style="max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"><?php echo htmlspecialchars($notice['title']); ?></div>
                                            <div class="subtitle">For: <?php echo htmlspecialchars(ucfirst($notice['target_role'])); ?></div>
                                        </div>
                                    </div>
                                    <span class="badge-tag"><?php echo date('M d, Y', strtotime($notice['created_at'])); ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php else: ?>
                            <p style="color: var(--text-muted); text-align: center; padding: 20px 0;">No notices posted yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

        </div><!-- end dashboard-content -->
    </div><!-- end dashboard-main -->
</div><!-- end dashboard-layout -->

<script>
// ===== Enrollment Trend Line Chart =====
const enrollLabels = <?php echo json_encode(array_column($enrollment_data, 'label')); ?>;
const enrollCounts = <?php echo json_encode(array_column($enrollment_data, 'count')); ?>;

new Chart(document.getElementById('enrollmentChart'), {
    type: 'line',
    data: {
        labels: enrollLabels,
        datasets: [{
            label: 'Students Enrolled',
            data: enrollCounts,
            borderColor: '#2563eb',
            backgroundColor: 'rgba(37, 99, 235, 0.08)',
            borderWidth: 2.5,
            fill: true,
            tension: 0.4,
            pointBackgroundColor: '#2563eb',
            pointBorderColor: '#fff',
            pointBorderWidth: 2,
            pointRadius: 5,
            pointHoverRadius: 7,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: false },
            tooltip: {
                backgroundColor: '#1e293b',
                titleFont: { family: 'Inter', weight: '600' },
                bodyFont: { family: 'Inter' },
                padding: 12,
                cornerRadius: 8,
                displayColors: false,
            }
        },
        scales: {
            x: {
                grid: { display: false },
                ticks: { font: { family: 'Inter', size: 12, weight: '500' }, color: '#94a3b8' }
            },
            y: {
                beginAtZero: true,
                grid: { color: 'rgba(226, 232, 240, 0.6)', drawBorder: false },
                ticks: { font: { family: 'Inter', size: 12 }, color: '#94a3b8', stepSize: 1 }
            }
        }
    }
});

// ===== Course Distribution Donut Chart =====
const courseLabels = <?php echo json_encode(array_column($course_stats, 'name')); ?>;
const rawCounts = <?php echo json_encode(array_map('intval', array_column($course_stats, 'student_count'))); ?>;

const totalStudentsInCourses = rawCounts.reduce((a, b) => a + b, 0);

let chartLabels, chartData, chartColors;

if (courseLabels.length > 0 && totalStudentsInCourses > 0) {
    chartLabels = courseLabels;
    chartData = rawCounts;
    const colorPalette = ['#2563eb', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];
    chartColors = colorPalette.slice(0, courseLabels.length);
} else if (courseLabels.length > 0) {
    chartLabels = courseLabels;
    chartData = courseLabels.map(() => 1);
    const mutedPalette = ['#93c5fd', '#6ee7b7', '#fde68a', '#fca5a5', '#c4b5fd', '#a5f3fc'];
    chartColors = mutedPalette.slice(0, courseLabels.length);
} else {
    chartLabels = ['No Courses Added'];
    chartData = [1];
    chartColors = ['#e2e8f0'];
}

new Chart(document.getElementById('courseChart'), {
    type: 'doughnut',
    data: {
        labels: chartLabels,
        datasets: [{
            data: chartData,
            backgroundColor: chartColors,
            borderWidth: 2,
            borderColor: '#ffffff',
            hoverOffset: 6,
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '65%',
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    padding: 14,
                    usePointStyle: true,
                    pointStyle: 'circle',
                    font: { family: 'Inter', size: 12, weight: '500' },
                    color: '#64748b'
                }
            },
            tooltip: {
                backgroundColor: '#1e293b',
                titleFont: { family: 'Inter', weight: '600' },
                bodyFont: { family: 'Inter' },
                padding: 12,
                cornerRadius: 8,
                callbacks: {
                    label: function(context) {
                        if (totalStudentsInCourses > 0) {
                            return ` ${context.label}: ${rawCounts[context.dataIndex]} student(s)`;
                        } else if (courseLabels.length > 0) {
                            return ` ${context.label}: 0 students assigned`;
                        } else {
                            return ' No courses added yet';
                        }
                    }
                }
            }
        }
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>
