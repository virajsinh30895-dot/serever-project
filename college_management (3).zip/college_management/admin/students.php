<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireRole('admin');

$success = '';
$error = '';

// Handle Add Student
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $course_id = !empty($_POST['course_id']) ? $_POST['course_id'] : NULL;

    if (empty($username) || empty($password) || empty($first_name) || empty($last_name) || empty($email)) {
        $error = 'Please fill in all required fields.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $error = 'Username is already taken.';
        } else {
            try {
                $pdo->beginTransaction();
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'student')");
                $stmt->execute([$username, $password_hash]);
                $user_id = $pdo->lastInsertId();

                $stmt = $pdo->prepare("INSERT INTO students (user_id, first_name, last_name, email, phone, course_id, enrollment_date) VALUES (?, ?, ?, ?, ?, ?, CURDATE())");
                $stmt->execute([$user_id, $first_name, $last_name, $email, $phone, $course_id]);

                $pdo->commit();
                $success = 'Student added successfully.';
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = 'Failed to add student.';
            }
        }
    }
}

// Handle Edit Student / Course Assignment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $student_id = $_POST['student_id'];
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $phone = trim($_POST['phone']);
    $course_id = !empty($_POST['course_id']) ? $_POST['course_id'] : NULL;

    try {
        $stmt = $pdo->prepare("UPDATE students SET first_name = ?, last_name = ?, phone = ?, course_id = ? WHERE id = ?");
        $stmt->execute([$first_name, $last_name, $phone, $course_id, $student_id]);
        $success = "Student profile and course assignment updated successfully.";
    } catch(PDOException $e) {
        $error = "Failed to update student.";
    }
}

// Handle student deletion
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    try {
        $stmt = $pdo->prepare("SELECT user_id FROM students WHERE id = ?");
        $stmt->execute([$delete_id]);
        $student = $stmt->fetch();
        
        if ($student) {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$student['user_id']]);
            $success = "Student deleted successfully.";
        }
    } catch(PDOException $e) {
        $error = "Error deleting student.";
    }
}

// Fetch all courses for assignment dropdown
$courses = $pdo->query("SELECT * FROM courses ORDER BY name ASC")->fetchAll();

// Fetch all students with course info
$students = $pdo->query("
    SELECT s.id, s.first_name, s.last_name, s.email, s.phone, s.enrollment_date, s.course_id, c.name as course_name 
    FROM students s 
    LEFT JOIN courses c ON s.course_id = c.id
    ORDER BY s.id DESC
")->fetchAll();

require_once '../includes/header.php';

$sidebar_role = 'admin';
$current_page = 'students.php';
require_once '../includes/sidebar.php';
?>

<div class="dashboard-layout">
    <div class="dashboard-main">
        <?php
        $page_title = 'Manage Students';
        require_once '../includes/topbar.php';
        ?>

        <div class="dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4 animate-fade-in-up">
                <div class="page-header mb-0">
                    <h1>Manage Students</h1>
                    <p>View and manage registered students, enrollments, and course assignments.</p>
                </div>
                <button class="btn btn-primary shadow-sm rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#addStudentModal">
                    <i class="bi bi-person-plus-fill me-2"></i>Add Student
                </button>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="content-card animate-fade-in-up">
                <div class="content-card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Assigned Course</th>
                                    <th>Enrolled Date</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($students) > 0): ?>
                                    <?php foreach($students as $student): ?>
                                        <tr>
                                            <td>#<?php echo htmlspecialchars($student['id']); ?></td>
                                            <td class="fw-semibold"><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></td>
                                            <td><?php echo htmlspecialchars($student['email']); ?></td>
                                            <td><?php echo htmlspecialchars($student['phone'] ?? 'N/A'); ?></td>
                                            <td>
                                                <?php if($student['course_name']): ?>
                                                    <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-3 py-1"><?php echo htmlspecialchars($student['course_name']); ?></span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle px-3 py-1">Not assigned</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($student['enrollment_date']); ?></td>
                                            <td class="text-end">
                                                <button class="btn btn-sm btn-outline-primary me-1" data-bs-toggle="modal" data-bs-target="#editStudentModal<?php echo $student['id']; ?>">
                                                    <i class="bi bi-pencil-square me-1"></i>Assign / Edit
                                                </button>
                                                <a href="?delete_id=<?php echo $student['id']; ?>" class="btn btn-sm btn-outline-danger btn-delete">
                                                    <i class="bi bi-trash me-1"></i>Delete
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted py-4">No students found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Student Modals (Rendered outside table to prevent DOM backdrop freezing) -->
<?php if(count($students) > 0): ?>
    <?php foreach($students as $student): ?>
        <div class="modal fade" id="editStudentModal<?php echo $student['id']; ?>" tabindex="-1" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content glass-card border-0">
              <div class="modal-header border-bottom-0">
                <h5 class="modal-title fw-bold text-primary">Edit Student & Assign Course</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <form method="POST" action="students.php">
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="student_id" value="<?php echo $student['id']; ?>">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">First Name *</label>
                            <input type="text" class="form-control" name="first_name" value="<?php echo htmlspecialchars($student['first_name']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Last Name *</label>
                            <input type="text" class="form-control" name="last_name" value="<?php echo htmlspecialchars($student['last_name']); ?>" required>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-semibold">Phone</label>
                            <input type="text" class="form-control" name="phone" value="<?php echo htmlspecialchars($student['phone'] ?? ''); ?>">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label fw-semibold">Assign Course</label>
                            <select class="form-select" name="course_id">
                                <option value="">-- Select Course --</option>
                                <?php foreach($courses as $c): ?>
                                    <option value="<?php echo $c['id']; ?>" <?php echo ($student['course_id'] == $c['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($c['code'] . ' - ' . $c['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-top-0">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary px-4 shadow-sm">Save Changes</button>
                </div>
              </form>
            </div>
          </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<!-- Add Student Modal -->
<div class="modal fade" id="addStudentModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content glass-card border-0">
      <div class="modal-header border-bottom-0">
        <h5 class="modal-title fw-bold text-primary">Add New Student</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="POST" action="students.php" class="needs-validation" novalidate>
        <div class="modal-body">
            <input type="hidden" name="action" value="add">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label fw-semibold">First Name *</label>
                    <input type="text" class="form-control" name="first_name" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Last Name *</label>
                    <input type="text" class="form-control" name="last_name" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Email *</label>
                    <input type="email" class="form-control" name="email" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Phone</label>
                    <input type="text" class="form-control" name="phone">
                </div>
                <div class="col-md-12">
                    <label class="form-label fw-semibold">Assign Course (Optional)</label>
                    <select class="form-select" name="course_id">
                        <option value="">-- Select Course --</option>
                        <?php foreach($courses as $c): ?>
                            <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['code'] . ' - ' . $c['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <hr class="my-4">
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Username *</label>
                    <input type="text" class="form-control" name="username" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Password *</label>
                    <input type="password" class="form-control" name="password" required>
                </div>
            </div>
        </div>
        <div class="modal-footer border-top-0">
            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary px-4 shadow-sm">Save Student</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
