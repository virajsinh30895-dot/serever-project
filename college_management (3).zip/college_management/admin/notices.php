<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireRole('admin');

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $target_role = $_POST['target_role'];
    $posted_by = $_SESSION['user_id'];

    if (empty($title) || empty($content)) {
        $error = 'Title and content are required.';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO notices (title, content, posted_by, target_role) VALUES (?, ?, ?, ?)");
            $stmt->execute([$title, $content, $posted_by, $target_role]);
            $success = 'Notice published successfully.';
        } catch (PDOException $e) {
            $error = 'Failed to publish notice.';
        }
    }
}

if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM notices WHERE id = ?");
        $stmt->execute([$delete_id]);
        $success = "Notice deleted successfully.";
    } catch(PDOException $e) {
        $error = "Error deleting notice.";
    }
}

$notices = $pdo->query("SELECT n.*, u.username as poster_name FROM notices n JOIN users u ON n.posted_by = u.id ORDER BY n.id DESC")->fetchAll();

require_once '../includes/header.php';

$sidebar_role = 'admin';
$current_page = 'notices.php';
require_once '../includes/sidebar.php';
?>

<div class="dashboard-layout">
    <div class="dashboard-main">
        <?php
        $page_title = 'Manage Notices';
        require_once '../includes/topbar.php';
        ?>

        <div class="dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4 animate-fade-in-up">
                <div class="page-header mb-0">
                    <h1>Manage Notices</h1>
                    <p>Publish campus announcements and view notice history.</p>
                </div>
                <button class="btn btn-primary shadow-sm rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#addNoticeModal">
                    <i class="bi bi-megaphone-fill me-2"></i>Publish Notice
                </button>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="content-card animate-fade-in-up">
                <div class="content-card-body p-0">
                    <div class="list-group list-group-flush border-0">
                        <?php if(count($notices) > 0): ?>
                            <?php foreach($notices as $notice): ?>
                                <div class="list-group-item p-4 bg-transparent border-bottom">
                                    <div class="d-flex w-100 justify-content-between align-items-start mb-2">
                                        <h5 class="mb-1 fw-bold"><?php echo htmlspecialchars($notice['title']); ?></h5>
                                        <small class="text-muted"><?php echo date('M d, Y h:i A', strtotime($notice['created_at'])); ?></small>
                                    </div>
                                    <p class="mb-3 text-secondary"><?php echo nl2br(htmlspecialchars($notice['content'])); ?></p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <small class="text-muted">
                                            Target: <span class="badge bg-info-subtle text-info border border-info-subtle text-capitalize"><?php echo htmlspecialchars($notice['target_role']); ?></span>
                                            <span class="mx-2">•</span> Posted by: <?php echo htmlspecialchars($notice['poster_name']); ?>
                                        </small>
                                        <a href="?delete_id=<?php echo $notice['id']; ?>" class="btn btn-sm btn-outline-danger btn-delete">
                                            <i class="bi bi-trash me-1"></i>Delete
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="p-5 text-center text-muted">No notices published yet.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addNoticeModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content glass-card border-0">
      <div class="modal-header border-bottom-0">
        <h5 class="modal-title fw-bold text-primary">Publish New Notice</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST" action="notices.php" class="needs-validation" novalidate>
        <div class="modal-body">
            <input type="hidden" name="action" value="add">
            <div class="mb-3">
                <label class="form-label fw-semibold">Title *</label>
                <input type="text" class="form-control" name="title" required>
            </div>
            <div class="mb-3">
                <label class="form-label fw-semibold">Content *</label>
                <textarea class="form-control" name="content" rows="5" required></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label fw-semibold">Target Audience</label>
                <select class="form-select" name="target_role">
                    <option value="all">Everyone</option>
                    <option value="student">Students Only</option>
                    <option value="teacher">Teachers Only</option>
                </select>
            </div>
        </div>
        <div class="modal-footer border-top-0">
            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary px-4 shadow-sm">Publish</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
