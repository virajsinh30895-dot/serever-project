<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireRole('admin');

$success = '';
$error = '';

// Get current admin user
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$admin = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_username = trim($_POST['username']);
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($new_username)) {
        $error = "Username is required.";
    } else {
        // Check if username changed and is unique
        if ($new_username !== $admin['username']) {
            $check = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
            $check->execute([$new_username, $admin['id']]);
            if ($check->fetch()) {
                $error = "That username is already taken.";
            }
        }

        // Handle password change if requested
        if (!$error && !empty($new_password)) {
            if (!password_verify($current_password, $admin['password_hash'])) {
                $error = "Current password is incorrect.";
            } elseif ($new_password !== $confirm_password) {
                $error = "New passwords do not match.";
            } elseif (strlen($new_password) < 6) {
                $error = "New password must be at least 6 characters.";
            }
        }

        if (!$error) {
            try {
                if (!empty($new_password)) {
                    $hash = password_hash($new_password, PASSWORD_DEFAULT);
                    $update = $pdo->prepare("UPDATE users SET username = ?, password_hash = ? WHERE id = ?");
                    $update->execute([$new_username, $hash, $admin['id']]);
                } else {
                    $update = $pdo->prepare("UPDATE users SET username = ? WHERE id = ?");
                    $update->execute([$new_username, $admin['id']]);
                }
                $success = "Profile updated successfully.";
                $_SESSION['username'] = $new_username;

                // Refresh data
                $stmt->execute([$_SESSION['user_id']]);
                $admin = $stmt->fetch();
            } catch (PDOException $e) {
                $error = "Failed to update profile.";
            }
        }
    }
}

require_once '../includes/header.php';

$sidebar_role = 'admin';
$current_page = 'profile.php';
require_once '../includes/sidebar.php';
?>

<div class="dashboard-layout">
    <div class="dashboard-main">
        <?php
        $page_title = 'Admin Profile';
        require_once '../includes/topbar.php';
        ?>

        <div class="dashboard-content">
            <div class="page-header animate-fade-in-up">
                <h1>Admin Profile</h1>
                <p>Manage your admin account settings and change your password.</p>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-8 col-lg-6">
                    <div class="content-card animate-fade-in-up">
                        <div class="content-card-header">
                            <h3>Account Settings</h3>
                        </div>
                        <div class="content-card-body">
                            <form method="POST" action="profile.php" class="needs-validation" novalidate>
                                <div class="row g-3">
                                    <div class="col-md-12">
                                        <label class="form-label fw-semibold">Username *</label>
                                        <input type="text" class="form-control" name="username" value="<?php echo htmlspecialchars($admin['username']); ?>" required>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label fw-semibold">Role</label>
                                        <input type="text" class="form-control bg-light" value="Administrator" readonly disabled>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="form-label fw-semibold">Account Created</label>
                                        <input type="text" class="form-control bg-light" value="<?php echo date('F d, Y', strtotime($admin['created_at'])); ?>" readonly disabled>
                                    </div>
                                </div>
                                
                                <hr class="my-4">
                                <h6 class="fw-bold mb-3">Change Password <small class="text-muted fw-normal">(leave blank to keep current)</small></h6>
                                
                                <div class="row g-3">
                                    <div class="col-md-12">
                                        <label class="form-label fw-semibold">Current Password</label>
                                        <input type="password" class="form-control" name="current_password">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-semibold">New Password</label>
                                        <input type="password" class="form-control" name="new_password">
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-semibold">Confirm New Password</label>
                                        <input type="password" class="form-control" name="confirm_password">
                                    </div>
                                </div>
                                
                                <div class="mt-4 text-end">
                                    <button type="submit" class="btn btn-primary px-4 shadow-sm rounded-pill">Update Profile</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
