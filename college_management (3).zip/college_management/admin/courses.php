<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireRole('admin');

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $code = trim($_POST['code']);
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);

    if (empty($code) || empty($name)) {
        $error = 'Course Code and Name are required.';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO courses (code, name, description) VALUES (?, ?, ?)");
            $stmt->execute([$code, $name, $description]);
            $success = 'Course added successfully.';
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $error = 'Course code already exists.';
            } else {
                $error = 'Failed to add course.';
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $course_id = $_POST['course_id'];
    $code = trim($_POST['code']);
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);

    if (empty($code) || empty($name)) {
        $error = 'Course Code/ID and Name are required.';
    } else {
        try {
            $stmt = $pdo->prepare("UPDATE courses SET code = ?, name = ?, description = ? WHERE id = ?");
            $stmt->execute([$code, $name, $description, $course_id]);
            $success = 'Course updated successfully.';
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $error = 'Course Code / ID already exists.';
            } else {
                $error = 'Failed to update course.';
            }
        }
    }
}

if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM courses WHERE id = ?");
        $stmt->execute([$delete_id]);
        $success = "Course deleted successfully.";
    } catch(PDOException $e) {
        $error = "Error deleting course.";
    }
}

$courses = $pdo->query("SELECT * FROM courses ORDER BY id DESC")->fetchAll();

require_once '../includes/header.php';

$sidebar_role = 'admin';
$current_page = 'courses.php';
require_once '../includes/sidebar.php';
?>

<div class="dashboard-layout">
    <div class="dashboard-main">
        <?php
        $page_title = 'Manage Courses';
        require_once '../includes/topbar.php';
        ?>

        <div class="dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4 animate-fade-in-up">
                <div class="page-header mb-0">
                    <h1>Manage Courses</h1>
                    <p>Create and update academic courses offered in the college.</p>
                </div>
                <button class="btn btn-primary shadow-sm rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#addCourseModal">
                    <i class="bi bi-plus-lg me-2"></i>Add Course
                </button>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="content-card animate-fade-in-up">
                <div class="content-card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead>
                                <tr>
                                    <th style="width: 70px;">#</th>
                                    <th>Course Code / ID</th>
                                    <th>Course Name</th>
                                    <th>Description</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($courses) > 0): ?>
                                    <?php foreach($courses as $course): ?>
                                        <tr>
                                            <td class="text-muted fw-semibold">#<?php echo htmlspecialchars($course['id']); ?></td>
                                            <td><span class="badge bg-primary-subtle text-primary border border-primary-subtle fw-semibold px-3 py-1 fs-6"><?php echo htmlspecialchars($course['code']); ?></span></td>
                                            <td class="fw-semibold text-dark fs-6"><?php echo htmlspecialchars($course['name']); ?></td>
                                            <td class="text-muted small"><?php echo htmlspecialchars($course['description'] ?? 'No description'); ?></td>
                                            <td class="text-end">
                                                <button class="btn btn-sm btn-outline-primary me-1" data-bs-toggle="modal" data-bs-target="#editCourseModal<?php echo $course['id']; ?>">
                                                    <i class="bi bi-pencil-square me-1"></i>Edit
                                                </button>
                                                <a href="?delete_id=<?php echo $course['id']; ?>" class="btn btn-sm btn-outline-danger btn-delete">
                                                    <i class="bi bi-trash me-1"></i>Delete
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="5" class="text-center text-muted py-4">No courses found.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Course Modals -->
<?php if(count($courses) > 0): ?>
    <?php foreach($courses as $course): ?>
        <div class="modal fade" id="editCourseModal<?php echo $course['id']; ?>" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content glass-card border-0">
              <div class="modal-header border-bottom-0">
                <h5 class="modal-title fw-bold text-primary">Edit Course</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <form method="POST" action="courses.php" class="needs-validation" novalidate>
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="course_id" value="<?php echo $course['id']; ?>">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Course Code / ID *</label>
                        <input type="text" class="form-control" name="code" value="<?php echo htmlspecialchars($course['code']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Course Name *</label>
                        <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($course['name']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Description</label>
                        <textarea class="form-control" name="description" rows="3"><?php echo htmlspecialchars($course['description'] ?? ''); ?></textarea>
                    </div>
                </div>
                <div class="modal-footer border-top-0">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary px-4 shadow-sm">Save Changes</button>
                </div>
              </form>
            </div>
          </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<!-- Add Course Modal -->
<div class="modal fade" id="addCourseModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content glass-card border-0">
      <div class="modal-header border-bottom-0">
        <h5 class="modal-title fw-bold text-primary">Add New Course</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST" action="courses.php" class="needs-validation" novalidate>
        <div class="modal-body">
            <input type="hidden" name="action" value="add">
            <div class="mb-3">
                <label class="form-label fw-semibold">Course Code / ID *</label>
                <input type="text" class="form-control" name="code" placeholder="e.g. CS101 or BTECH-CSE" required>
            </div>
            <div class="mb-3">
                <label class="form-label fw-semibold">Course Name *</label>
                <input type="text" class="form-control" name="name" placeholder="e.g. Computer Science & Engineering" required>
            </div>
            <div class="mb-3">
                <label class="form-label fw-semibold">Description</label>
                <textarea class="form-control" name="description" rows="3" placeholder="Brief description of the course..."></textarea>
            </div>
        </div>
        <div class="modal-footer border-top-0">
            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary px-4 shadow-sm">Save Course</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
