<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireRole('admin');

$success = '';
$error = '';

$courses = $pdo->query("SELECT * FROM courses ORDER BY name ASC")->fetchAll();
$selected_course = $_GET['course_id'] ?? '';
$exam_name = $_GET['exam_name'] ?? '';

// Save Marks
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_id = $_POST['course_id'];
    $exam = trim($_POST['exam_name']);
    $total_marks = $_POST['total_marks'] ?? 100;
    $marks_data = $_POST['marks'] ?? [];

    if (!empty($course_id) && !empty($exam)) {
        try {
            $pdo->beginTransaction();
            
            foreach ($marks_data as $student_id => $obtained) {
                if ($obtained !== '') {
                    $stmt = $pdo->prepare("SELECT id FROM marks WHERE student_id = ? AND course_id = ? AND exam_name = ?");
                    $stmt->execute([$student_id, $course_id, $exam]);
                    $exists = $stmt->fetch();

                    if ($exists) {
                        $stmt = $pdo->prepare("UPDATE marks SET marks_obtained = ?, total_marks = ? WHERE id = ?");
                        $stmt->execute([$obtained, $total_marks, $exists['id']]);
                    } else {
                        $stmt = $pdo->prepare("INSERT INTO marks (student_id, course_id, exam_name, marks_obtained, total_marks) VALUES (?, ?, ?, ?, ?)");
                        $stmt->execute([$student_id, $course_id, $exam, $obtained, $total_marks]);
                    }
                }
            }
            
            $pdo->commit();
            $success = "Marks saved successfully.";
            $selected_course = $course_id;
            $exam_name = $exam;
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Failed to save marks.";
        }
    }
}

$students = [];
$existing_marks = [];
$total_marks_val = 100;

if ($selected_course) {
    $stmt = $pdo->prepare("SELECT id, first_name, last_name FROM students WHERE course_id = ? ORDER BY first_name ASC");
    $stmt->execute([$selected_course]);
    $students = $stmt->fetchAll();

    if ($exam_name) {
        $stmt = $pdo->prepare("SELECT student_id, marks_obtained, total_marks FROM marks WHERE course_id = ? AND exam_name = ?");
        $stmt->execute([$selected_course, $exam_name]);
        while ($row = $stmt->fetch()) {
            $existing_marks[$row['student_id']] = $row['marks_obtained'];
            $total_marks_val = $row['total_marks'];
        }
    }
}

require_once '../includes/header.php';

$sidebar_role = 'admin';
$current_page = 'marks.php';
require_once '../includes/sidebar.php';
?>

<div class="dashboard-layout">
    <div class="dashboard-main">
        <?php
        $page_title = 'Manage Marks';
        require_once '../includes/topbar.php';
        ?>

        <div class="dashboard-content">
            <div class="page-header animate-fade-in-up">
                <h1>Manage Marks</h1>
                <p>Enter and manage exam grades and test scores for all students.</p>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="content-card mb-4 animate-fade-in-up">
                <div class="content-card-body">
                    <form method="GET" class="row g-3 align-items-end">
                        <div class="col-md-5">
                            <label class="form-label fw-semibold">Select Course</label>
                            <select class="form-select" name="course_id" required onchange="this.form.submit()">
                                <option value="">-- Select Course --</option>
                                <?php foreach($courses as $c): ?>
                                    <option value="<?php echo $c['id']; ?>" <?php echo ($selected_course == $c['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($c['code'] . ' - ' . $c['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Exam/Test Name</label>
                            <input type="text" class="form-control" name="exam_name" placeholder="e.g. Midterm 1" value="<?php echo htmlspecialchars($exam_name); ?>" required>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-outline-primary w-100 rounded-pill">Load Students</button>
                        </div>
                    </form>
                </div>
            </div>

            <?php if ($selected_course && $exam_name): ?>
                <div class="content-card animate-fade-in-up">
                    <div class="content-card-body">
                        <?php if(count($students) > 0): ?>
                            <form method="POST" action="marks.php">
                                <input type="hidden" name="course_id" value="<?php echo htmlspecialchars($selected_course); ?>">
                                <input type="hidden" name="exam_name" value="<?php echo htmlspecialchars($exam_name); ?>">
                                
                                <div class="mb-4 row align-items-center bg-light p-3 rounded-3 mx-0 border">
                                    <label class="col-sm-3 col-form-label fw-bold">Total Marks for this Exam:</label>
                                    <div class="col-sm-3">
                                        <input type="number" class="form-control" name="total_marks" value="<?php echo htmlspecialchars($total_marks_val); ?>" required>
                                    </div>
                                </div>

                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-4">
                                        <thead>
                                            <tr>
                                                <th>Student ID</th>
                                                <th>Name</th>
                                                <th style="width: 200px;">Marks Obtained</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($students as $s): ?>
                                                <?php $obtained = $existing_marks[$s['id']] ?? ''; ?>
                                                <tr>
                                                    <td>#<?php echo htmlspecialchars($s['id']); ?></td>
                                                    <td class="fw-semibold"><?php echo htmlspecialchars($s['first_name'] . ' ' . $s['last_name']); ?></td>
                                                    <td>
                                                        <input type="number" step="0.01" class="form-control" name="marks[<?php echo $s['id']; ?>]" value="<?php echo htmlspecialchars($obtained); ?>" placeholder="0.00">
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="text-end">
                                    <button type="submit" class="btn btn-primary px-5 rounded-pill shadow-sm">Save Marks</button>
                                </div>
                            </form>
                        <?php else: ?>
                            <div class="text-center py-4 text-muted">No students enrolled in this course.</div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
