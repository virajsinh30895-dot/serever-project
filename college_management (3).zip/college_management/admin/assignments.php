<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireRole('admin');

$success = '';
$error = '';

$courses = $pdo->query("SELECT * FROM courses ORDER BY name ASC")->fetchAll();
$teachers = $pdo->query("SELECT id, first_name, last_name FROM teachers ORDER BY first_name ASC")->fetchAll();

// Handle Add Assignment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $course_id = $_POST['course_id'];
    $teacher_id = $_POST['teacher_id'];
    $due_date = $_POST['due_date'];
    $file_path = '';

    if (empty($title) || empty($course_id) || empty($teacher_id) || empty($due_date)) {
        $error = 'Title, Course, Teacher, and Due Date are required.';
    } else {
        // Handle file upload
        if (isset($_FILES['assignment_file']) && $_FILES['assignment_file']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../assets/uploads/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            $filename = time() . '_' . basename($_FILES['assignment_file']['name']);
            $target_file = $upload_dir . $filename;
            
            if (move_uploaded_file($_FILES['assignment_file']['tmp_name'], $target_file)) {
                $file_path = 'assets/uploads/' . $filename;
            } else {
                $error = 'Failed to upload file.';
            }
        }

        if (!$error) {
            try {
                $stmt = $pdo->prepare("INSERT INTO assignments (title, description, file_path, teacher_id, course_id, due_date) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $description, $file_path, $teacher_id, $course_id, $due_date]);
                $success = 'Assignment posted successfully.';
            } catch (PDOException $e) {
                $error = 'Failed to post assignment.';
            }
        }
    }
}

// Handle Delete
if (isset($_GET['delete_id'])) {
    try {
        $stmt = $pdo->prepare("DELETE FROM assignments WHERE id = ?");
        $stmt->execute([$_GET['delete_id']]);
        $success = "Assignment deleted successfully.";
    } catch (PDOException $e) {
        $error = "Failed to delete assignment.";
    }
}

// Fetch all assignments
$assignments = $pdo->query("
    SELECT a.*, c.name as course_name, c.code as course_code, t.first_name as teacher_fname, t.last_name as teacher_lname 
    FROM assignments a 
    JOIN courses c ON a.course_id = c.id 
    JOIN teachers t ON a.teacher_id = t.id 
    ORDER BY a.due_date DESC
")->fetchAll();

require_once '../includes/header.php';

$sidebar_role = 'admin';
$current_page = 'assignments.php';
require_once '../includes/sidebar.php';
?>

<div class="dashboard-layout">
    <div class="dashboard-main">
        <?php
        $page_title = 'Manage Assignments';
        require_once '../includes/topbar.php';
        ?>

        <div class="dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4 animate-fade-in-up">
                <div class="page-header mb-0">
                    <h1>Manage Assignments</h1>
                    <p>View, create, and manage all course assignments across the system.</p>
                </div>
                <button class="btn btn-primary shadow-sm rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#addAssignmentModal">
                    <i class="bi bi-file-earmark-plus-fill me-2"></i>Post Assignment
                </button>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="content-card animate-fade-in-up">
                <div class="content-card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Course</th>
                                    <th>Posted By</th>
                                    <th>Due Date</th>
                                    <th>Attachment</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($assignments) > 0): ?>
                                    <?php foreach($assignments as $assignment): ?>
                                        <tr>
                                            <td class="fw-semibold">
                                                <?php echo htmlspecialchars($assignment['title']); ?>
                                                <?php if($assignment['description']): ?>
                                                    <br><small class="text-muted fw-normal"><?php echo htmlspecialchars(substr($assignment['description'], 0, 50)) . '...'; ?></small>
                                                <?php endif; ?>
                                            </td>
                                            <td><span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle"><?php echo htmlspecialchars($assignment['course_name']); ?></span></td>
                                            <td>Prof. <?php echo htmlspecialchars($assignment['teacher_fname'] . ' ' . $assignment['teacher_lname']); ?></td>
                                            <td>
                                                <?php 
                                                $due = strtotime($assignment['due_date']);
                                                $now = time();
                                                $class = ($due < $now) ? 'text-danger fw-bold' : 'text-dark';
                                                ?>
                                                <span class="<?php echo $class; ?>"><?php echo date('M d, Y', $due); ?></span>
                                            </td>
                                            <td>
                                                <?php if($assignment['file_path']): ?>
                                                    <a href="../<?php echo htmlspecialchars($assignment['file_path']); ?>" target="_blank" class="btn btn-sm btn-outline-info rounded-pill">
                                                        <i class="bi bi-file-earmark-arrow-down me-1"></i>View File
                                                    </a>
                                                <?php else: ?>
                                                    <span class="text-muted small">No file</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-end">
                                                <a href="?delete_id=<?php echo $assignment['id']; ?>" class="btn btn-sm btn-outline-danger btn-delete">
                                                    <i class="bi bi-trash me-1"></i>Delete
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="6" class="text-center text-muted py-4">No assignments posted.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addAssignmentModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content glass-card border-0">
      <div class="modal-header border-bottom-0">
        <h5 class="modal-title fw-bold text-primary">Post New Assignment</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST" action="assignments.php" enctype="multipart/form-data" class="needs-validation" novalidate>
        <div class="modal-body">
            <input type="hidden" name="action" value="add">
            <div class="mb-3">
                <label class="form-label fw-semibold">Assignment Title *</label>
                <input type="text" class="form-control" name="title" required>
            </div>
            <div class="row mb-3">
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Course *</label>
                    <select class="form-select" name="course_id" required>
                        <option value="">Select Course...</option>
                        <?php foreach($courses as $c): ?>
                            <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['code'] . ' - ' . $c['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Assign Teacher *</label>
                    <select class="form-select" name="teacher_id" required>
                        <option value="">Select Teacher...</option>
                        <?php foreach($teachers as $t): ?>
                            <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['first_name'] . ' ' . $t['last_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Due Date *</label>
                    <input type="date" class="form-control" name="due_date" required>
                </div>
            </div>
            <div class="mb-3">
                <label class="form-label fw-semibold">Description</label>
                <textarea class="form-control" name="description" rows="4"></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label fw-semibold">Attachment (Optional)</label>
                <input type="file" class="form-control" name="assignment_file">
                <div class="form-text">Upload a document, PDF, or zip file.</div>
            </div>
        </div>
        <div class="modal-footer border-top-0">
            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary px-4 shadow-sm">Post Assignment</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
