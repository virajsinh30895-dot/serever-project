<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireRole('admin');

$success = '';
$error = '';

// Handle add teacher
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $department = trim($_POST['department']);

    if (empty($username) || empty($password) || empty($first_name) || empty($last_name) || empty($email)) {
        $error = 'Please fill in all required fields.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $error = 'Username is already taken.';
        } else {
            try {
                $pdo->beginTransaction();
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'teacher')");
                $stmt->execute([$username, $password_hash]);
                $user_id = $pdo->lastInsertId();

                $stmt = $pdo->prepare("INSERT INTO teachers (user_id, first_name, last_name, email, phone, department) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$user_id, $first_name, $last_name, $email, $phone, $department]);

                $pdo->commit();
                $success = 'Teacher added successfully.';
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = 'Failed to add teacher.';
            }
        }
    }
}

// Handle delete teacher
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    try {
        $stmt = $pdo->prepare("SELECT user_id FROM teachers WHERE id = ?");
        $stmt->execute([$delete_id]);
        $teacher = $stmt->fetch();
        if ($teacher) {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$teacher['user_id']]);
            $success = "Teacher deleted successfully.";
        }
    } catch(PDOException $e) {
        $error = "Error deleting teacher.";
    }
}

$teachers = $pdo->query("SELECT * FROM teachers ORDER BY id DESC")->fetchAll();

require_once '../includes/header.php';

$sidebar_role = 'admin';
$current_page = 'teachers.php';
require_once '../includes/sidebar.php';
?>

<div class="dashboard-layout">
    <div class="dashboard-main">
        <?php
        $page_title = 'Manage Teachers';
        require_once '../includes/topbar.php';
        ?>

        <div class="dashboard-content">
            <div class="d-flex justify-content-between align-items-center mb-4 animate-fade-in-up">
                <div class="page-header mb-0">
                    <h1>Manage Teachers</h1>
                    <p>Add and manage teaching faculty in the college.</p>
                </div>
                <button class="btn btn-primary shadow-sm rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#addTeacherModal">
                    <i class="bi bi-person-plus-fill me-2"></i>Add Teacher
                </button>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle me-2"></i><?php echo htmlspecialchars($success); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="content-card animate-fade-in-up">
                <div class="content-card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Department</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($teachers) > 0): ?>
                                    <?php foreach($teachers as $teacher): ?>
                                        <tr>
                                            <td>#<?php echo htmlspecialchars($teacher['id']); ?></td>
                                            <td class="fw-semibold"><?php echo htmlspecialchars($teacher['first_name'] . ' ' . $teacher['last_name']); ?></td>
                                            <td><?php echo htmlspecialchars($teacher['email']); ?></td>
                                            <td><?php echo htmlspecialchars($teacher['phone'] ?? 'N/A'); ?></td>
                                            <td><span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle"><?php echo htmlspecialchars($teacher['department'] ?? 'General'); ?></span></td>
                                            <td class="text-end">
                                                <a href="?delete_id=<?php echo $teacher['id']; ?>" class="btn btn-sm btn-outline-danger btn-delete">
                                                    <i class="bi bi-trash me-1"></i>Delete
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr><td colspan="6" class="text-center text-muted py-4">No teachers found.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Teacher Modal -->
<div class="modal fade" id="addTeacherModal" tabindex="-1" aria-labelledby="addTeacherModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content glass-card border-0">
      <div class="modal-header border-bottom-0">
        <h5 class="modal-title fw-bold text-primary" id="addTeacherModalLabel">Add New Teacher</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="POST" action="teachers.php" class="needs-validation" novalidate>
        <div class="modal-body">
            <input type="hidden" name="action" value="add">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label fw-semibold">First Name *</label>
                    <input type="text" class="form-control" name="first_name" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Last Name *</label>
                    <input type="text" class="form-control" name="last_name" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Email *</label>
                    <input type="email" class="form-control" name="email" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Phone</label>
                    <input type="text" class="form-control" name="phone">
                </div>
                <div class="col-md-12">
                    <label class="form-label fw-semibold">Department</label>
                    <input type="text" class="form-control" name="department">
                </div>
                <hr class="my-4">
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Username *</label>
                    <input type="text" class="form-control" name="username" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-semibold">Password *</label>
                    <input type="password" class="form-control" name="password" required>
                </div>
            </div>
        </div>
        <div class="modal-footer border-top-0">
            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary px-4 shadow-sm">Save Teacher</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
