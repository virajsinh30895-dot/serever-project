<?php
/**
 * Dashboard Top Bar Component
 * 
 * Variables expected:
 * - $page_title: Title of the current page
 */

$page_title = $page_title ?? 'Dashboard';
$username = $_SESSION['username'] ?? 'User';
$role = $_SESSION['role'] ?? '';
$initials = strtoupper(substr($username, 0, 2));
?>

<header class="topbar">
    <!-- Mobile Menu Toggle -->
    <button class="topbar-icon-btn d-lg-none" onclick="document.getElementById('sidebar').classList.toggle('open')">
        <i class="bi bi-list"></i>
    </button>

    <!-- Search -->
    <div class="topbar-search">
        <i class="bi bi-search"></i>
        <input type="text" placeholder="Search..." id="topbar-search-input">
    </div>

    <!-- Actions -->
    <div class="topbar-actions">
        <button class="topbar-icon-btn" title="Notifications">
            <i class="bi bi-bell"></i>
            <span class="badge-dot"></span>
        </button>

        <!-- User Dropdown -->
        <div class="dropdown">
            <div class="topbar-user" data-bs-toggle="dropdown" aria-expanded="false">
                <div class="topbar-avatar"><?php echo $initials; ?></div>
                <div class="topbar-user-info d-none d-sm-block">
                    <div class="name"><?php echo htmlspecialchars($username); ?></div>
                    <div class="role"><?php echo htmlspecialchars($role); ?></div>
                </div>
                <i class="bi bi-chevron-down" style="font-size: 12px; color: var(--text-muted);"></i>
            </div>
            <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 mt-2" style="border-radius: 12px; overflow: hidden;">
                <?php if ($role === 'student'): ?>
                    <li><a class="dropdown-item py-2" href="<?php echo BASE_URL; ?>student/profile.php"><i class="bi bi-person me-2"></i>My Profile</a></li>
                <?php endif; ?>
                <li><a class="dropdown-item py-2" href="<?php echo BASE_URL; ?>logout.php"><i class="bi bi-box-arrow-left me-2"></i>Logout</a></li>
            </ul>
        </div>
    </div>
</header>
