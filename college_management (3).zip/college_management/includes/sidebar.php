<?php
/**
 * Dashboard Sidebar Component
 * 
 * Variables expected:
 * - $sidebar_role: 'admin' | 'teacher' | 'student'
 * - $current_page: basename of the current page (e.g., 'index.php')
 * - $user_display_name: name to display in the sidebar (optional)
 */

$sidebar_role = $sidebar_role ?? '';
$current_page = $current_page ?? '';

// Define navigation items per role
$nav_items = [];

if ($sidebar_role === 'admin') {
    $nav_items = [
        ['icon' => 'bi-grid-1x2-fill', 'label' => 'Dashboard', 'href' => 'index.php'],
        ['icon' => 'bi-people-fill', 'label' => 'Students', 'href' => 'students.php'],
        ['icon' => 'bi-person-badge-fill', 'label' => 'Teachers', 'href' => 'teachers.php'],
        ['icon' => 'bi-journal-bookmark-fill', 'label' => 'Courses', 'href' => 'courses.php'],
        ['icon' => 'bi-clipboard-data-fill', 'label' => 'Marks', 'href' => 'marks.php'],
        ['icon' => 'bi-file-earmark-text-fill', 'label' => 'Assignments', 'href' => 'assignments.php'],
        ['icon' => 'bi-megaphone-fill', 'label' => 'Notices', 'href' => 'notices.php'],
        ['icon' => 'bi-person-fill-gear', 'label' => 'My Profile', 'href' => 'profile.php'],
    ];
} elseif ($sidebar_role === 'teacher') {
    $nav_items = [
        ['icon' => 'bi-grid-1x2-fill', 'label' => 'Dashboard', 'href' => 'index.php'],
        ['icon' => 'bi-clipboard-data-fill', 'label' => 'Enter Marks', 'href' => 'marks.php'],
        ['icon' => 'bi-file-earmark-text-fill', 'label' => 'Assignments', 'href' => 'assignments.php'],
    ];
} elseif ($sidebar_role === 'student') {
    $nav_items = [
        ['icon' => 'bi-grid-1x2-fill', 'label' => 'Dashboard', 'href' => 'index.php'],
        ['icon' => 'bi-person-fill', 'label' => 'My Profile', 'href' => 'profile.php'],
        ['icon' => 'bi-clipboard-data-fill', 'label' => 'My Marks', 'href' => 'marks.php'],
        ['icon' => 'bi-file-earmark-text-fill', 'label' => 'Assignments', 'href' => 'assignments.php'],
        ['icon' => 'bi-megaphone-fill', 'label' => 'Notices', 'href' => 'notices.php'],
    ];
}
?>

<aside class="sidebar" id="sidebar">
    <!-- Brand -->
    <div class="sidebar-brand">
        <div class="sidebar-brand-icon">
            <i class="bi bi-mortarboard-fill"></i>
        </div>
        <div class="sidebar-brand-text">
            <h5>Smart College</h5>
            
        </div>
    </div>

    <!-- Navigation -->
    <div class="sidebar-section-label">Main Menu</div>
    <ul class="sidebar-nav">
        <?php foreach ($nav_items as $item): ?>
            <li>
                <a href="<?php echo $item['href']; ?>" class="<?php echo ($current_page === $item['href']) ? 'active' : ''; ?>">
                    <i class="bi <?php echo $item['icon']; ?>"></i>
                    <?php echo $item['label']; ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>

    <!-- Footer -->
    <div class="sidebar-footer">
        <a href="<?php echo BASE_URL; ?>logout.php">
            <i class="bi bi-box-arrow-left"></i>
            Logout
        </a>
    </div>
</aside>
