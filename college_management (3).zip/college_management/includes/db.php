<?php
$host = 'localhost';
$dbname = 'college_management';
$username = 'root';
$password = '';

// Define BASE_URL dynamically based on the project folder location relative to server document root
if (!defined('BASE_URL')) {
    $doc_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
    $project_root = str_replace('\\', '/', dirname(__DIR__));
    $base_path = str_replace($doc_root, '', $project_root);
    
    $parts = explode('/', trim($base_path, '/'));
    $encoded_parts = array_map('rawurlencode', $parts);
    $base_url = '/' . implode('/', array_filter($encoded_parts));
    if ($base_url !== '/') {
        $base_url .= '/';
    }
    define('BASE_URL', $base_url);
}

try {
    // Try connecting to port 3306 first (standard on most laptops)
    try {
        $pdo = new PDO("mysql:host=$host;port=3306;dbname=$dbname;charset=utf8", $username, $password);
    } catch (PDOException $e) {
        // If 3306 fails or doesn't have the database, try port 3307
        $pdo = new PDO("mysql:host=$host;port=3307;dbname=$dbname;charset=utf8", $username, $password);
    }
    
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}