<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function hasRole($role) {
    return isset($_SESSION['role']) && $_SESSION['role'] === $role;
}

function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: " . BASE_URL . "login.php");
        exit;
    }
}

function requireRole($role) {
    requireLogin();
    if (!hasRole($role)) {
        header("Location: " . BASE_URL . "index.php"); // Or show 403 page
        exit;
    }
}

function redirectBasedOnRole() {
    if (isLoggedIn()) {
        $role = $_SESSION['role'];
        if ($role === 'admin') {
            header("Location: " . BASE_URL . "admin/index.php");
        } elseif ($role === 'student') {
            header("Location: " . BASE_URL . "student/index.php");
        }
        exit;
    }
}
?>
